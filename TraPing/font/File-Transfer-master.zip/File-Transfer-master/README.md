Computer Networks Project - Khulna University

Usage: Transfering files among several computers.

Features:

    1.User can see the list of computers connected with the same local area network.
    2.User can browse and send file to a computer from the list or by manually inserting the target computer's ip address.
    3.User can receive file from other computers.
    4.There is no limit of file size.


